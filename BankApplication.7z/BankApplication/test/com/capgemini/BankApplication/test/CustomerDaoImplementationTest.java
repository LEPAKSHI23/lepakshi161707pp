package com.capgemini.BankApplication.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.BankApplication.Been.Customer;
import com.capgemini.BankApplication.Dao.CustomerDaoImplementation;
import com.capgemini.BankApplication.Exception.BankException;

public class CustomerDaoImplementationTest {
Customer c=null;
CustomerDaoImplementation d=null;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Test
	public void testAddCustomer() throws BankException {
		c= new Customer(123654789632147l, "QQQQQ1111Q", "AAAA", "9998889998", "789654123036", 00.00, "WELCOME", "4563");
		d=new CustomerDaoImplementation();
		long b=d.addCustomer(c);
		assertEquals(123654789632145l,b);
	}

	@Test
	public void testShowBal()  throws BankException {
		d=new CustomerDaoImplementation();
		double b=d.showBal(100000);
		assertEquals(100.00, b);
	}

	@Test
	public void testWithdraw()  throws BankException{
		d=new CustomerDaoImplementation();
		double b=d.withdraw(789654123698745l,100000);
		assertEquals(100.00, b);
	}

	@Test
	public void testDeposit()  throws BankException {
		d=new CustomerDaoImplementation();
		double b=d.deposit(789654123698745l,100000);
		assertNotEquals(100.00, b,0);
	}

	@Test
	public void testFundTrans() throws BankException {
		d=new CustomerDaoImplementation();
		double b=d.fundTrans(123654789632145l,100000, 789654123698745l);
		assertEquals(100.00, b);;
	}

	@Test
	public void testPrintTrans() throws BankException {
		d=new CustomerDaoImplementation();
		String s=d.printTrans(123654789632145l);
		assertEquals("welcome",s);
	}

	@Test
	public void testChk() throws BankException {
		d=new CustomerDaoImplementation();
		 boolean b=d.chk(123654789632145l, "7896");
		 assertTrue("true",b);
		
	}

	@Test
	public void testChkacc() throws BankException {
		d=new CustomerDaoImplementation();
		 boolean b=d.chkacc(1789632145l);
		 assertFalse("false",b );
	}

	@Test
	public void testBalV() throws BankException{
		d=new CustomerDaoImplementation();
		 boolean b=d.balV(123654789632145l);
		 assertTrue("true",b);
	}

	@Test
	public void testMinBal() throws BankException {
		d=new CustomerDaoImplementation();
		 boolean b=d.minBal(123654789632145l);
		 assertTrue("true",b);
		 
	}

}
