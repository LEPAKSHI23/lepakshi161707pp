package com.capgemini.BankApplication.Exception;

@SuppressWarnings("serial")
public class BankException extends Exception {

	public BankException(String string) {
		// TODO Auto-generated constructor stub
		System.out.println(string);
	}

}
