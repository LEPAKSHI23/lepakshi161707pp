package com.capgemini.BankApplication.Been;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Entity
public class Customer {
	
	public Customer(){}
	public Customer(long accnum, String pan_num, String cname, String phnum,
			String adhar, double bal, String hist, String pwd) {
		super();
		this.accnum = accnum;
		this.pan_num = pan_num;
		this.cname = cname;
		this.phnum = phnum;
		this.adhar = adhar;
		this.bal = bal;
		this.hist = hist;
		this.pwd = pwd;
	}
	@Id

	/*@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "accnum")
	@SequenceGenerator(name="accnum")*/
	private long accnum;
		private String pan_num;
		@Column(name="cname",length=30,nullable=false)
		private String cname;
		@Column(name="phnum",length=10)
		private String phnum;
		
		
		@Column(name="adhar",length=12)
		private String adhar;
		
		private double bal;
		private String hist="welcome\n";
		@NotNull
		@Column(name="pwd",length=4)
		private String pwd; 
		
		public String getPwd() {
			return pwd;
		}
		public void setPwd(String pwd) {
			this.pwd = pwd;
		}
		public String getHist() {
			return hist;
		}
		public void setHist(String hist1) {
			this.hist = hist+hist1;
		}
		public double getBal() {
			return bal;
		}
		public void setBal(double bal) {
			this.bal = bal;
		}
		public String getPan_num() {
			return pan_num;
		}
		public void setPan_num(String pan_num) {
			this.pan_num = pan_num;
		}
		public String getCname() {
			return cname;
		}
		public void setCname(String cname) {
			this.cname = cname;
		}
		public String getPhnum() {
			return phnum;
		}
		public void setPhnum(String phnum) {
			this.phnum = phnum;
		}
		
		public String getAdhar() {
			return adhar;
		}
		public void setAdhar(String adhar) {
			this.adhar = adhar;
		}
		public long getAccnum() {
			return accnum;
		}
		public void setAccnum(long accnum) {
			this.accnum = accnum;
		}
		@Override
		public String toString() {
			return "Customer [account num=" + accnum + ", cname=" + cname + ", balance="
					+ bal + "]";
		
	}
	}



