package com.capgemini.BankApplication.Dao;

import javax.persistence.EntityManager;

import com.capgemini.BankApplication.Been.Customer;
import com.capgemini.BankApplication.Exception.BankException;
import com.capgemini.BankApplication.Utility.JPAUtil;

public class CustomerDaoImplementation implements ICustomerDao{
	//private EntityManager entityManager=null;
	//EntityManager entityManager=JPAUtil.getEntityManager();
	Customer temp= new Customer(); 
	static long accnum=123456789000000l;

	
@Override
	public long addCustomer(Customer c) throws BankException {
	EntityManager entityManager=JPAUtil.getEntityManager();
	try{
	//	System.out.println("hai");
		//entityManager =Persistence.createEntityManagerFactory("BankApplication").createEntityManager();
	  accnum=accnum+1;
	c.setAccnum(accnum);
		entityManager.getTransaction().begin();
		entityManager.persist(c);
		entityManager.getTransaction().commit();
		return c.getAccnum();
	}
	catch(Exception e)
	{throw new BankException(e.getMessage());}
	
finally
{entityManager.close();}
}

@Override
	public double showBal(long accnum) throws BankException {
	//EntityManager entityManager=JPAUtil.getEntityManager();	
	EntityManager entityManager=null;
	try{
		entityManager=JPAUtil.getEntityManager();
		temp=entityManager.find(Customer.class,accnum);
		return temp.getBal();
	}
	catch(Exception e)
	{throw new BankException(e.getMessage());}
	
finally
{entityManager.close();}
}
	
@Override
 public double withdraw(long accnum, double amt)  throws BankException{
	//EntityManager entityManager=JPAUtil.getEntityManager();
		EntityManager entityManager=null;	
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
	temp=entityManager.find(Customer.class,accnum);
	double nbal=temp.getBal()-amt;
	temp.setBal(nbal);
	temp.setHist("withdrawed ammount is,"+amt);
	entityManager.merge(temp);
	entityManager.getTransaction().commit();
	return temp.getBal();
}
	catch(Exception e)
	{throw new BankException(e.getMessage());}
	
finally
{entityManager.close();}
}
	

@Override
	public double deposit(long accnum, double amt) throws BankException {
	//EntityManager entityManager=JPAUtil.getEntityManager();
		EntityManager entityManager=null;	
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
	temp=entityManager.find(Customer.class,accnum);
	double nbal=temp.getBal()+amt;
	temp.setBal(nbal);
	temp.setHist("deposited ammount is,"+amt);
	entityManager.merge(temp);
	entityManager.getTransaction().commit();
	return temp.getBal();
		}
		catch(Exception e)
		{throw new BankException(e.getMessage());}
		
	finally
	{entityManager.close();}
	}
	
@Override
	public double fundTrans(long accnum, double amt, long tnum)  throws BankException{
    EntityManager entityManager=null;	
	//1EntityManager entityManager=JPAUtil.getEntityManager();
	try{
		entityManager=JPAUtil.getEntityManager();
		//entityManager.getTransaction().begin();
	  /*temp=entityManager.find(Customer.class,accnum);
	double nbal=temp.getBal()-amt;
	temp.setBal(nbal);*/
		withdraw(accnum, amt);
	//temp.setHist("transfered ammount is"+amt);
	temp.setHist("amount of "+amt+"is transfered to\n");
	entityManager.merge(temp);
	//temp.setHist("amount of "+amt+"is transfered to\n");
	//entityManager.getTransaction().commit();
	/*entityManager=JPAUtil.getEntityManager();*/
	//entityManager.getTransaction().begin();
	/*Customer temp1=entityManager.find(Customer.class,tnum);
	double nbal1=temp1.getBal()+amt;
	temp1.setBal(nbal1);*/
	deposit(tnum, amt);
	Customer temp1=new Customer();
	temp1.setHist("The ammount credited by transfer is ,"+amt);
	entityManager.merge(temp1);
	//entityManager.getTransaction().commit();
	return temp.getBal();
	}
catch(Exception e)
{throw new BankException(e.getMessage());}

finally
{entityManager.close();}
}
@Override
	public String printTrans(long accnum)  throws BankException{
	 EntityManager entityManager=null;
	 try{
	 entityManager=JPAUtil.getEntityManager();
	 entityManager.getTransaction().begin();
	temp=entityManager.find(Customer.class,accnum);
	String s=temp.getHist();
	entityManager.getTransaction().commit();
		return s;}
	 catch(Exception e)
	 {throw new BankException(e.getMessage());}

	 finally
	 {entityManager.close();}
	 
	 
	}

	public boolean chk(long accnum, String pwd) {
		EntityManager entityManager=JPAUtil.getEntityManager();
		boolean flag=false;
		Customer c=entityManager.find(Customer.class,accnum);
		if(c!=null)
		{
		if(pwd.equals(c.getPwd())){
			flag=true;
		}
		else
			return flag;
		}
		return flag;
	}
	public boolean chkacc(long accnum) {
		EntityManager entityManager=JPAUtil.getEntityManager();
		//try{
		Customer c=entityManager.find(Customer.class,accnum);
		if(c==null)
		return false;
		else 
			return true;
		
	}
	public boolean balV(long acnum) {
		EntityManager entityManager=JPAUtil.getEntityManager();
		Customer c=entityManager.find(Customer.class,acnum);
		boolean f= false;
		if(c.getBal()>=1500)
		{f=true;}
		return f;
	}
public boolean minBal(long acnum) {
	EntityManager entityManager=JPAUtil.getEntityManager();
	Customer c=entityManager.find(Customer.class,acnum);
		boolean f= false;
		if (c.getBal()>1500)
		f=true;
		return f;
	}

}
