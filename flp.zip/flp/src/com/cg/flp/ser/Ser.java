package com.cg.flp.ser;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.flp.dao.IDao;
import com.cg.flp.entity.Wish;
import com.cg.flp.excep.FlpException;
@Service
@Transactional
public class Ser implements Iser {
	
	@Autowired
	private IDao userDAO;
	


	public  int delete(int id,String emailId) throws FlpException {
		return userDAO.delete(id,emailId);
	}

	public List<Wish> showall(String emailId) throws FlpException {
		// TODO Auto-generated method stub
		return userDAO.showall( emailId);
	}

	public Wish add(int productId, String emailId)throws FlpException {
		// TODO Auto-generated method stub
		return userDAO.add( productId,emailId);
	}



	
}
