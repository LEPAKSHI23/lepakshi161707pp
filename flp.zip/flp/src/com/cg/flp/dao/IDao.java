package com.cg.flp.dao;

import java.util.ArrayList;



import java.util.List;

import com.cg.flp.entity.Wish;
import com.cg.flp.excep.FlpException;

public interface IDao {
	
	
	public int delete(int id,String email) throws  FlpException ;

	
	public List<Wish> showall(String emailId) throws FlpException ;

	public Wish add(int productId, String emailId)throws FlpException;
}
