package com.cg.flp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import org.springframework.stereotype.Repository;

import com.cg.flp.entity.CustomerLogin;
import com.cg.flp.entity.Product;
import com.cg.flp.entity.Wish;
import com.cg.flp.excep.FlpException;

@Repository
public class Dao implements IDao{
	@PersistenceContext
	private EntityManager entityManager;
	

	public Wish add(int productId, String emailId) throws FlpException {
		Wish wishlist=new Wish();
		try {
			CustomerLogin c=entityManager.find(CustomerLogin.class,emailId);
	        Product p = entityManager.find(Product.class, productId);
			wishlist.setProductDescription(p.getProductDescription());
			wishlist.setProductId(p.getProductId());
			wishlist.setProductName(p.getProductName());
			wishlist.setProductPrice(p.getProductPrice());
			wishlist.setCustomeremailId(c.getEmailId());
			System.out.println(wishlist);
			entityManager.persist(wishlist);
		
				return wishlist;
			
		
			
		} catch (PersistenceException e) {
			throw new FlpException(e.getMessage());
		}
		

	}
	
	
	public List<Wish> showall(String emailId) throws FlpException {
	
		System.out.println("hi");
		return entityManager.createQuery("Select w from Wish w where w.customeremailId='"+emailId+"'", Wish.class).getResultList();
	}
	

	public int delete(int id,String emailId) throws FlpException {
		try {
			Wish w=entityManager.createQuery("Select w from Wish w where w.customeremailId='"+emailId+"' and w.productId='"+id+"'", Wish.class).getSingleResult();
			entityManager.remove(w);
			/*if(w.getProductId()==id){
			System.out.println(w);	
			entityManager.createQuery("delete Wish  where wishId='"+w.getWishId()+"'", Wish.class);
			}*/return 1;
		} catch (PersistenceException e) {
			throw new FlpException(e.getMessage());
		}
	}
}
