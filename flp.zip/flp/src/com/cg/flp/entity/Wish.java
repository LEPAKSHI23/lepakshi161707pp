package com.cg.flp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="wishlist")
public class Wish  {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
private int wishId;
	public int getWishId() {
		return wishId;
	}
	public void setWishId(int wishId) {
		this.wishId = wishId;
	}
	@Column(name="customer_emailId")
	private String customeremailId;
	
	@Column(name="product_Name")
	private String productName;
	@Column(name="product_Description")
	private String productDescription ;
	@Column(name="product_Price")
	private Double productPrice;
	@Column(name="product_Id")
	private Integer productId;	
	
	
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public Double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getCustomeremailId() {
		return customeremailId;
	}
	public void setCustomeremailId(String customeremailId) {
		this.customeremailId = customeremailId;
	}
	@Override
	public String toString() {
		return "Wish [productName=" + productName + ", productDescription="
				+ productDescription + ", productPrice=" + productPrice
				+ ", productId=" + productId + ", customeremailId="
				+ customeremailId + "]";
	}
	
}
