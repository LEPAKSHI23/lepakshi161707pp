package com.cg.flp.ser;

import java.util.ArrayList;



import com.cg.flp.entity.Wish;
import com.cg.flp.excep.FlpException;

public interface Iser {
	
	
	public int delete(int id) throws  FlpException ;
	public ArrayList<Wish> showall(String emailId) throws FlpException ;
	public Integer add(int productId, String emailId)throws FlpException;
}
