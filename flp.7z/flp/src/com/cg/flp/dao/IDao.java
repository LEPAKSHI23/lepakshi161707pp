package com.cg.flp.dao;

import java.util.ArrayList;



import com.cg.flp.entity.Wish;
import com.cg.flp.excep.FlpException;

public interface IDao {
	
	
	public int delete(int id) throws  FlpException ;

	
	public ArrayList<Wish> showall(String emailId) throws FlpException ;

	public Integer add(int productId, String emailId)throws FlpException;
}
