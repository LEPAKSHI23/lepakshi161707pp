package com.cg.flp.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="customer_login")
public class Customer {
	
	@Id
	String email_Id;

	String password;
	String name;
	int phoneNumber;
	String address;
	

	public String getEmail_Id() {
		return email_Id;
	}

	public void setEmail_Id(String email_Id) {
		this.email_Id = email_Id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "CustomerLoginEntity [email_Id=" + email_Id + ", password="
				+ password + ", name=" + name + ", phoneNumber=" + phoneNumber
				+ ", address=" + address + "]";
	}
	
	


}
