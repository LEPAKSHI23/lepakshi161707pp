package com.cg.flp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.flp.entity.Wish;
import com.cg.flp.ser.Iser;

@Controller
public class WishlistController {
	@Autowired
	private Iser userService;

	@RequestMapping(value = "/register")
	public ModelAndView processForm(
			@RequestParam(value = "productId") int productId,
			@RequestParam(value = "emailId") String emailId) {

		try {

			Wish wish= userService.add(productId, emailId);
			
	
			if (wish!=null) 
			{
				return new ModelAndView("cust", "message",
						wish);
			} else {
				return new ModelAndView("cust_status", "message",
						"Unable to add product to wishlist");
			}

		} catch (Exception e) {
			return new ModelAndView("sucess", "error", e.getMessage());
		}

	}

	
	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView processForm(
			@RequestParam(value = "emailid") String emailId) {

		
		try {
System.out.println("hello");
			List<Wish> wishlist = userService.showall(emailId);
			System.out.println("done");
			if (wishlist != null) {
				System.out.println("finally");
				return new ModelAndView("wishlist", "message", wishlist);
			} else {
				return new ModelAndView("wishlist", "message",
						"no item in wishlist");
			}
		} catch (Exception e) {
			return new ModelAndView("sucess", "error", e.getMessage());
		}
	}

	@RequestMapping(value = "/deleteproduct")
	public ModelAndView delete(@RequestParam(value = "id") int productId,@RequestParam(value = "emailId") String emailId) {
		try {
			System.out.println("del");

			int n = userService.delete(productId,emailId);
			if (n > 0) {
				return new ModelAndView("custrem", "message",
						"Record Deleted");
			} else {
				return new ModelAndView("cust_status", "message",
						"Unable to Delete  Record");
			}
		} catch (Exception e) {
			return new ModelAndView("sucess", "error", e.getMessage());
		}
	}

}
