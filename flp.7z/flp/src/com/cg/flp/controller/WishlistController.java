package com.cg.flp.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.flp.entity.Wish;
import com.cg.flp.excep.FlpException;
import com.cg.flp.ser.Iser;

@Controller
public class WishlistController {
	@Autowired
	private Iser userService;

	@RequestMapping(value = "/register")
	public ModelAndView processForm(
			@RequestParam(value = "product_Id") int product_Id,
			@RequestParam(value = "emailId") String emailId) {

		try {

			Integer n = userService.add(product_Id, emailId);

			System.out.println(n);
			if (n > 0) {
				return new ModelAndView("cust", "message",
						" product added to wishlist");
			} else {
				return new ModelAndView("cust_status", "message",
						"Unable to add product to wishlist");
			}

		} catch (Exception e) {
			return new ModelAndView("sucess", "error", e.getMessage());
		}

	}

	
	@RequestMapping(value = "/display", method = RequestMethod.POST)
	public ModelAndView processForm(
			@RequestParam(value = "emailId") String emailId) {

		System.out.println("display controller");
		try {

			ArrayList<Wish> wishlist = userService.showall(emailId);
			if (wishlist != null) {
				return new ModelAndView("wishlist", "message", wishlist);
			} else {
				return new ModelAndView("wishlist", "message",
						"no item in wishlist");
			}
		} catch (Exception e) {
			return new ModelAndView("sucess", "error", e.getMessage());
		}
	}

	@RequestMapping(value = "/deleteproduct", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam(value = "Product_Id") Integer Product_Id) {
		try {

			int n = userService.delete(Product_Id);
			if (n > 0) {
				return new ModelAndView("cust", "message",
						" Record Deleted");
			} else {
				return new ModelAndView("cust_status", "message",
						"Unable to Delete  Record");
			}
		} catch (FlpException e) {
			return new ModelAndView("sucess", "error", e.getMessage());
		}
	}

}
